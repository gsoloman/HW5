/**
 * Created by chaika on 02.02.16.
 */
var Templates = require("../Templates");
// Чтобы была возможность вызвать addToCart(pizza)
var PizzaCart = require("./PizzaCart");
var Pizza_List = require("../Pizza_List");

//HTML едемент куди будуть додаватися піци
var $pizza_list = $("#pizza-list");

var $pizza_count = $("#header-count");

initFilters();

function initFilters() {
    $("#filter_all").click(function() {
        clearFilters();
        $("#filter_all").addClass("active");
        filterPizza("all");
    });
    $("#filter_meat").click(function() {
        clearFilters();
        $("#filter_meat").addClass("active");
        filterPizza("meat");
    });
    $("#filter_pineapple").click(function() {
        clearFilters();
        $("#filter_pineapple").addClass("active");
        filterPizza("pineapples");
    });
    $("#filter_fish").click(function() {
        clearFilters();
        $("#filter_fish").addClass("active");
        filterPizza("fish");
    });
    $("#filter_mushrooms").click(function() {
        clearFilters();
        $("#filter_mushrooms").addClass("active");
        filterPizza("mushrooms");
    });
    $("#filter_vega").click(function() {
        clearFilters();
        $("#filter_vega").addClass("active");
        filterPizza("vega");
    });
}

// Чтобы деактивировать текущий фильтр
function clearFilters() {
    $("#filters_list")
        .children()
        .each(function(i) {
            $(this).removeClass("active");
        });
}

function showPizzaList(list) {
    //Очищаємо старі піци в кошику
    $pizza_list.html("");
    $pizza_count.text(list.length);

    //Онволення однієї піци
    function showOnePizza(pizza) {
        var html_code = Templates.PizzaMenu_OneItem({ pizza: pizza });

        var $node = $(html_code);

        $node.find(".buy-big").click(function() {
            PizzaCart.addToCart(pizza, PizzaCart.PizzaSize.Big);
        });
        $node.find(".buy-small").click(function() {
            PizzaCart.addToCart(pizza, PizzaCart.PizzaSize.Small);
        });

        $pizza_list.append($node);
    }

    list.forEach(function(item) {
        showOnePizza(item);
    });
}

function filterPizza(filter) {
    if (filter === "all") {
        setTitle("all");
        showPizzaList(Pizza_List);
        return;
    }

    //Масив куди потраплять піци які треба показати
    var pizza_shown = [];

    Pizza_List.forEach(function(pizza) {
        if (filter === "meat" && pizza.content.meat)
            pizza_shown.push(pizza);
        if (filter === "pineapples" && pizza.content.pineapple)
            pizza_shown.push(pizza);
        if (filter === "fish" && pizza.content.ocean)
            pizza_shown.push(pizza);
        if (filter === "mushrooms" && pizza.content.mushroom)
            pizza_shown.push(pizza);
        if (filter === "vega" && !pizza.content.meat && !pizza.content.chicken && !pizza.content.ocean)
            pizza_shown.push(pizza);
    });

    setTitle(filter);

    //Показати відфільтровані піци
    showPizzaList(pizza_shown);
}

// filter - "м'ясні", "з ананасами"...
function setTitle(filter) {
    var title = "Усі піци";
    switch (filter) {
        case "meat":
            title = "Піци з м'ясом";
            break;
        case "pineapples":
            title = "Піци з ананасами";
            break;
        case "fish":
            title = "Піци з морепродуктами";
            break;
        case "mushrooms":
            title = "Піци з грибами";
            break;
        case "vega":
            title = "Піци вега";
            break;
    }
    $("#header-title").text(title);
}

function initialiseMenu() {
    //Показуємо усі піци
    showPizzaList(Pizza_List);
    setTitle("all");
}

exports.filterPizza = filterPizza;
exports.initialiseMenu = initialiseMenu;
